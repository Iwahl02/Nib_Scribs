var img1;
var img2;
var img3;

function preload() {

  img1 = loadImage("Flowers.jpg");
  img2 = loadImage("Clouds.jpg");
  img3 = loadImage("Bee.png");
}
function setup() {
  createCanvas(400, 400);
  
}

function draw() {
  background(220);

push()
  image(img1, -120, 0);

  image(img1, 130, 0, 420, 420);

  image(img2, 0, 0, mouseY, mouseY);

  image(img3,mouseX,mouseY,300,300);
pop()

  push()
  stroke(0)
  strokeWeight(4)
  textFont('Bell MT')
  textSize(50)
  fill(170)
  text('Busy Bees',260,20,150,150)
  
  pop()
}
