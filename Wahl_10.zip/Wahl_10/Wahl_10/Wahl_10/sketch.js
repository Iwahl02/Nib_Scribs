function setup() {
  createCanvas(600, 600);
  ellipseMode(CENTER);
 
}

function draw() {
  colorMode(RGB, 255, 255, 255, 1);
background(255);


push()

fillGradient('linear', {
    from : [0, 0],   // x, y : Coordinates
    to : [600, 600], // x, y : Coordinates
    steps : [
        color(229,196,247,97),
        color(169,171,250,98),
        color(155,114,247,97)
    ] // Array of p5.color objects or arrays containing [p5.color Object, Color Stop (0 to 1)]
});

rect(0,0,600,600)

pop()


  push()

  fillGradient('radial', {
    from : [100, 100, 100],  
    to : [500, 500, 200], 
    steps : [
        color(255),
        color(247, 218, 114,97),
        color(247,183,114,97)
    ] 
});

  
  stroke (25, 100, 0, 0.3);

  
  strokeWeight (2);

  
  ellipse(150, 150, 200, 200);

  pop()

push()

fillGradient('conic', {
    from : [400, 400, 0],
    steps : [
        color(250,189,152,98),
        color(250,198,135,98),
        color(250,74,70,98)
    ] 
});
strokeWeight(2)
stroke(250,75,165,98)
triangle(300,300,500,500,250,400,400)

pop()

push()

fillGradient('radial', {
    from : [300, 300, 300], // x, y, radius
    to : [300, 300, 10], // x, y, radius
    steps : [
        color(102,250,122,98),
        color(62,250,215,98),
        color(0)
    ] 
});

strokeWeight(2)
stroke(158,152,250,98)
ellipse(300,530,100,100)

pop()


push()

fillGradient('radial', {
    from : [400, 400, 500],
    to : [200, 200, 300], 
    steps : [
        color(177,51,250,98),
        color(243,70,250,98),
        color(250,146,195,98)
    ] 
});
strokeWeight(2)
stroke(250,75,165,98)
ellipse(500,100,300,300)

pop()






}  

